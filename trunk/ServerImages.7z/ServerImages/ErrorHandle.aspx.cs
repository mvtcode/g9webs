﻿using System;

public partial class ErrorHandle : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var requestpage = Request.ServerVariables["QUERY_STRING"].Replace("404;", "");
        if (requestpage.Contains("upload"))
        {
            requestpage = requestpage.Substring(requestpage.IndexOf("upload"));
            var arequestpage = requestpage.Split("/".ToCharArray());
            string url;
            try
            {
                var atargetfile = arequestpage[arequestpage.Length - 1].Split(".".ToCharArray());
                int sourceId;
                if (!int.TryParse(arequestpage[arequestpage.Length - 2], out sourceId))
                {
                }
                var w = atargetfile[atargetfile.Length - 3];
                var h = atargetfile[atargetfile.Length - 2];
                var f = "";
                for (var i = 0; i < arequestpage.Length - 1; i++)
                {
                    f += arequestpage[i] + "/";
                }
                for (var i = 0; i < atargetfile.Length - 3; i++)
                {
                    f += atargetfile[i];
                    if (i < atargetfile.Length - 4) f += ".";
                }
                f = f.Replace("/", "\\");
                try
                {
                    Convert.ToInt32(w);
                    Convert.ToInt32(h);
                    url = "/srv_thumb.ashx?source=" + sourceId + "&w=" + w + "&h=" + h + "&f=" + f;
                }
                catch (Exception)
                {
                    url = "/upload/images/no_images.jpg";
                }

            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
                url = "/upload/images/no_images.jpg";
            }
            Response.Redirect(url);
        }
        else
        {
            Response.Write("Không tìm thấy trang bạn yêu cầu!");
        }
    }
}
